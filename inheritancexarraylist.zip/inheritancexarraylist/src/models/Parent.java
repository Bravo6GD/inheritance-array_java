package models;

public class Parent {
    public String family_name = "Karki";
    public String houseAddress = "Kathmandu";
}